/*
 * hw.h
 *
 *  Created on: Jul 3, 2022
 *      Author: paulo
 */

#ifndef HW_H_
#define HW_H_

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);
void hw_delay_ms(uint32_t time_ms);
void hw_led_toggle(void);
void hw_cpu_sleep(void);
uint32_t hw_tick_ms_get(void);

#endif /* HW_H_ */
