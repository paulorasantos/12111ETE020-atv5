/*
 * app.h
 *
 *  Created on: Jul 3, 2022
 *      Author: paulo
 */
#include <stdbool.h>

#ifndef APP_H_
#define APP_H_

void app_init(void);
void app_loop(void);
void app_switch_interrupt(bool buton);
void app_tick_1ms(void);

#endif /* APP_H_ */
