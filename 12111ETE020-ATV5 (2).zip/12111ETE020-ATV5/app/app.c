/*
 * app.c
 *
 *  Created on: Jul 3, 2022
 *      Author: paulo
 */

#include <stdint.h>
#include <stdbool.h>
#include "app.h"
#include "hw.h"

typedef enum app_led_state_e
{
	APP_LED_IDLE = 0,
	APP_LED_HEAT,
	APP_LED_COOL
} app_led_state_t;

typedef enum
{
	AC_INIT = 0,
	AC_IDLE,
	AC_HEAT,
	AC_COOL
} ac_states_t;

typedef struct
{
	ac_states_t state;
	float set_point_c;
	float histerese_c;
	float temp_room_c;
} ac_sm_t;

#define APP_DEBOUCING_TIME_MS 50

volatile uint32_t led_time_ms = 500;

uint32_t time_led_delay = 100;
//float tempRoom = 25.0;
//float tempSP = 25.0;
ac_sm_t sm = { 0 };

app_led_state_t led_state = APP_LED_IDLE;

/*float ac_read_temp_c(){
	return tempRoom;
}

float ac_read_set_point_c(){
	return tempSP;
}
*/

void ac_cool_set(bool state)
{
	if(state)
	{
	    led_state = APP_LED_COOL;
	    led_time_ms = 100;
	}
	else
	{
		led_state = APP_LED_IDLE;
		led_time_ms = 500;
	}
}

void ac_heat_set(bool state)
{
	if(state)
	{
	    led_state = APP_LED_HEAT;
	    led_time_ms = 1000;
	}
	else
	{
		led_state = APP_LED_IDLE;
		led_time_ms = 500;
	}
}

//void app_tick_1ms(void)
//{
	// piscar o led de acordo com o estado dele (led_state)
//}

void app_interrupt_inc_temp(void)
{
	sm.temp_room_c += 0.5;
}

void app_interrupt_dec_temp(void)
{
	sm.temp_room_c -= 0.5;
}

void ac_run_sm(ac_sm_t *sm)
{
	//float temp_c = ac_read_temp_c();
	//sm->set_point_c = ac_read_set_point_c();
	switch(sm->state){
	case AC_INIT: // inicialização do que for preciso
		sm->set_point_c = 25;
		sm->histerese_c = 2;
		sm->temp_room_c = 25;
		sm->state = AC_IDLE;
		//led_time_ms = 500;
		break;
	case AC_IDLE:
		ac_cool_set(false);
		ac_heat_set(false);
		if(sm->temp_room_c >= (sm->set_point_c + sm->histerese_c)){
			sm->state = AC_COOL;
			//led_time_ms = 100;
		}
		else if(sm->temp_room_c <= (sm->set_point_c - sm->histerese_c)){
			sm->state = AC_HEAT;
			//led_time_ms = 1000;
		}
		break;
	case AC_HEAT:
		ac_heat_set(true);
		if(sm->temp_room_c > sm->set_point_c){
			sm->state = AC_IDLE;
			//led_time_ms = 500;
		}
		break;
	case AC_COOL:
		ac_cool_set(true);
		if(sm->temp_room_c < sm->set_point_c){
			sm->state = AC_IDLE;
			//led_time_ms = 500;
		}
		break;
	default: // isto nunca deveria acontecer
		sm->state = AC_INIT;
		break;
	}
}

void app_switch_interrupt(bool buton){
	// INTERRUPÇÃO A SER REALIZADA
	// DEBOUCING - FALHAS MECÂNICAS BOTÕES
	static uint32_t deboucing_time_ms = 0;

	if((hw_tick_ms_get() - deboucing_time_ms) >= APP_DEBOUCING_TIME_MS)
	{
		// VERIFICAR QUAL BOTÃO APERTOU E INCREMENTAR NA VARIÁVEL tempRoom
		if(buton)
			// BOTÃO COOL = 1
			app_interrupt_inc_temp();
		else
			// BOTÃO HEAT = 0
			app_interrupt_dec_temp();

		deboucing_time_ms = hw_tick_ms_get();
	}
}


void app_tick_1ms(void)
{
	// CONTADOR DO TEMPO

	static uint32_t led_time_cnt_ms = 0;

	led_time_cnt_ms++;

	// QUANDO ATINGIR O TEMPO DO PISCAR DO LED
	if(led_time_cnt_ms >= led_time_ms)
	{
		led_time_cnt_ms = 0;
		hw_led_toggle();
	}
}

void app_init(void)
{
	sm.state = AC_INIT;
}

void app_loop(void)
{
	ac_run_sm(&sm);
}


