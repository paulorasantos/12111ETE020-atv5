/*
 * hw.c
 *
 *  Created on: Jul 3, 2022
 *      Author: paulo
 */
#include <stdint.h>
#include "main.h"
#include "app.h"

void hw_delay_ms(uint32_t time_ms){
	HAL_Delay(time_ms);
}

void hw_led_toggle(void){
	HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	if(GPIO_Pin == AUMENTAR_Pin){
		app_switch_interrupt(1);
	}
	if(GPIO_Pin == DIMINUIR_Pin){
		app_switch_interrupt(0);
	}
}

void hw_cpu_sleep(void){
	__WFI();
}

