/*
 * app.c
 *
 *  Created on: Jul 3, 2022
 *      Author: paulo
 */

#include <stdint.h>
#include <stdbool.h>
#include "app.h"
#include "hw.h"

volatile uint32_t led_time_ms = 500;

uint32_t time_led_delay = 100;
float tempRoom = 25.0;
float tempSP = 25.0;

typedef enum
{
	AC_INIT = 0,
	AC_IDLE,
	AC_HEAT,
	AC_COOL
} ac_states_t;

typedef struct
{
	ac_states_t state;
	float set_point_c;
	float histerese_c;
} ac_sm_t;

float ac_read_temp_c(){
	return tempRoom;
}

float ac_read_set_point_c(){
	return tempSP;
}

void ac_run_sm(ac_sm_t *sm){
	float temp_c = ac_read_temp_c();
	sm->set_point_c = ac_read_set_point_c();
		switch(sm->state){
		case AC_INIT: // inicialização do que for preciso
			sm->histerese_c = 2.0;
			sm->state = AC_IDLE;
			led_time_ms = 500;
			break;
		case AC_IDLE:
			ac_cool_set(false);
			ac_heat_set(false);
			if(temp_c > (sm->set_point_c + sm->histerese_c)){
				sm->state = AC_COOL;
				led_time_ms = 100;
			}
			else if(temp_c < (sm->set_point_c - sm->histerese_c)){
				sm->state = AC_HEAT;
				led_time_ms = 1000;
			}
			break;
		case AC_HEAT:
			ac_heat_set(true);
			if(temp_c > sm->set_point_c){
				sm->state = AC_IDLE;
				led_time_ms = 500;
			}
			break;
		case AC_COOL:
			ac_cool_set(true);
			if(temp_c < sm->set_point_c){
				sm->state = AC_IDLE;
				led_time_ms = 500;
			}
			break;
		default: // isto nunca deveria acontecer
			sm->state = AC_INIT;
			break;
	}
}

void app_switch_interrupt(bool buton){
	// INTERRUPÇÃO A SER REALIZADA
	// VERIFICAR QUAL BOTÃO APERTOU E INCREMENTAR NA VARIÁVEL tempRoom

	if(buton)
		// BOTÃO COOL = 1
		tempRoom -= 0.5;
	else
		// BOTÃO HEAT = 0
		tempRoom += 0.5;

}


void app_tick_1ms(void){
	// CONTADOR DO TEMPO

	static uint32_t led_time_cnt_ms = 0;

	led_time_cnt_ms++;

	// QUANDO ATINGIR O TEMPO DO PISCAR DO LED
	if(led_time_cnt_ms >= led_time_ms){
		led_time_cnt_ms = 0;
		hw_led_toggle();
	}
}

void app_init(void){
}

void app_loop(void){
	hw_cpu_sleep();
}


